# * Right now I declare this project as dead *

### 15/4/2018 Hi friends, Sorry i didn't looked at the issues but at this time I have lot of things in my school, I promised to update the code and fix the issues (2 months)

# Instahack (Instabrute)
![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg?style=flat-square)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ARVABYAUX3NPC)

## The script is not compatible with Android yet! 

### Please dont open a new issue before you search if issue already exists
### Please open issue with clear name

## How to use
###### First install all the required modules
```
pip install argparse requests PySocks asyncio proxybroker
```
###### Run the script
```
python instabrute.py USERNAME PASSWORD_FILE
//Example: "python instabrute.py username passwords.txt"
```
## Todo List
- [x] Finish the base
- [ ] Proxy things improvement

## Modules
1. argparse
2. requests
3. PySocks
4. asyncio
5. proxybroker

## Screenshots
###### [*] Hack instagram accounts use bruteforce
![alt tag](https://raw.githubusercontent.com/avramit/instahack/master/screenshot.png)

### * 21/2/2018 Update - The whole code has been rewritten
